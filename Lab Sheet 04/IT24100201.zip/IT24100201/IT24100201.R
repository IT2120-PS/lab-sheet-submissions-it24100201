setwd("C:\\Users\\it24100201\\Desktop\\IT24100201")
getwd()

# Import the dataset into R
branch_data <- read.table("Exercise.txt", header = TRUE, sep = ",")
fix(branch_data)


# Check the structure of the dataset
str(branch_data)



# Create a boxplot for sales
boxplot(branch_data$Sales, 
        main = "Boxplot of Sales", 
        ylab = "Sales Amount",
        outline=TRUE,
        horizontal=FALSE)
